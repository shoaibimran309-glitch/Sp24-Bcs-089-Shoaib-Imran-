# Student Card Flutter App

A simple Flutter project that displays a professional digital student card.

## Features
- Student profile card
- Student photo/avatar
- Name, roll number, department, semester and email
- University information
- Clean responsive UI
- No external database required

## Project Structure

```text
student_card/
├── android/
├── lib/
│   └── main.dart
├── screenshots/
│   ├── student_card_pc.png
│   └── student_card_mobile.png
├── pubspec.yaml
└── README.md
```

## Requirements

- Flutter SDK
- Android Studio or VS Code
- Android SDK
- A connected Android device/emulator, or Chrome/Windows for testing

## Run the project

```bash
flutter pub get
flutter run
```

For Windows desktop:

```bash
flutter config --enable-windows-desktop
flutter run -d windows
```

For Chrome:

```bash
flutter run -d chrome
```

## Customize Student Information

Open:

```text
lib/main.dart
```

and change the values such as:

- Student Name
- Roll Number
- Department
- Semester
- Email
- University

## Build APK

```bash
flutter build apk --release
```

The generated APK will normally be available in:

```text
build/app/outputs/flutter-apk/app-release.apk
```
