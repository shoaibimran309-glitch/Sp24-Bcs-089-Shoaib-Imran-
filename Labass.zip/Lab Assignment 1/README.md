# Lab Assignment 1 – Flutter SQLite CRUD App

## Features
- Create/Add student records
- Read/display saved records
- Edit and Update existing records
- Delete records
- Local SQLite database using `sqflite`
- Data remains saved after the app is closed/reopened
- Image, name, email and age fields
- Material 3 UI

## Required GitHub structure
Upload this folder to the shared repository:

`Lab Assignment 1/`

Included:
- `lib/`
- `pubspec.yaml`
- `screenshots/`

## Run
1. Open the project in Android Studio or VS Code.
2. Run `flutter pub get`.
3. Start an Android emulator or connect a physical Android phone.
4. Run `flutter run`.

## Screenshot warning
The files in `screenshots/` are clearly labeled placeholders. After testing on an emulator/physical device, replace them with actual screenshots showing:
1. Add operation
2. Update operation
3. Delete operation

Do not submit placeholders as proof of testing.

## SQLite
Database: `student_records.db`
Table: `students`

Columns:
- `id`
- `imageUrl`
- `name`
- `email`
- `age`

## CRUD mapping
Create → Add Record
Read → Student Records list
Update → Edit / Update
Delete → Delete
