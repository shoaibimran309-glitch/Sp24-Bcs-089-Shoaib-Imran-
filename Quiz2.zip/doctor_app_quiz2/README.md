# CarePoint Doctor App — Quiz 2 Activity

A Flutter patient-record app demonstrating local CRUD with SQLite, patient image selection, and document attachment selection.

## Features
- Create, view, edit, and delete patient records.
- SQLite database stored locally on the device; works offline after installation.
- Search patients by name, diagnosis, or phone number.
- Attach an image from the gallery and choose a patient document (PDF, image, DOC/DOCX).
- Modern teal/navy interface, form validation, delete confirmation, and patient detail screen.

## Run the project
1. Install Flutter SDK and Android Studio (or another Flutter-supported target).
2. Extract this ZIP and open the `doctor_app_quiz2` folder in VS Code.
3. Open the terminal in the project folder and run:
   ```bash
   flutter pub get
   flutter run
   ```
4. To build an Android APK:
   ```bash
   flutter build apk --release
   ```
   The APK is generated at `build/app/outputs/flutter-apk/app-release.apk`.

## Important platform notes
- `sqflite` uses a local SQLite database. The database is created automatically on first launch.
- Image and document paths are stored in the patient record. This starter project selects files from the device but does not copy them into app-managed storage; if your assignment requires files to remain available after source-file moves or Android scoped-storage changes, implement a copy-to-app-documents step.
- The project targets Android/iOS. Desktop targets may require platform-specific plugin setup.
- For Android, the current `image_picker` and `file_picker` plugins usually need no extra configuration for basic selection. Follow each plugin's current documentation if your SDK requests permission or manifest changes.

## Screenshots
The `screenshots/` folder contains **design previews** of the app screens for documentation. They are not captured from a running Flutter emulator. For an authentic submission, run the Flutter app and replace/add these with screenshots captured directly from your emulator/device:
1. Patient list
2. Add patient form
3. Patient details
4. Edit patient form
5. Delete confirmation

## Suggested screenshot capture
Run the app, add a demo patient with fictional data, then use your emulator/device screenshot shortcut. Do not use real patient information in coursework screenshots.
