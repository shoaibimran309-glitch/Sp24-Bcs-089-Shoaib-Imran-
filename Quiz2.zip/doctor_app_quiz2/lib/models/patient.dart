class Patient {
  final int? id;
  final String name;
  final int age;
  final String gender;
  final String phone;
  final String diagnosis;
  final String notes;
  final String? imagePath;
  final String? documentPath;
  final String createdAt;

  const Patient({
    this.id,
    required this.name,
    required this.age,
    required this.gender,
    required this.phone,
    required this.diagnosis,
    required this.notes,
    this.imagePath,
    this.documentPath,
    required this.createdAt,
  });

  Map<String, Object?> toMap() => {
        'id': id,
        'name': name,
        'age': age,
        'gender': gender,
        'phone': phone,
        'diagnosis': diagnosis,
        'notes': notes,
        'imagePath': imagePath,
        'documentPath': documentPath,
        'createdAt': createdAt,
      };

  factory Patient.fromMap(Map<String, Object?> map) => Patient(
        id: map['id'] as int?,
        name: map['name'] as String,
        age: map['age'] as int,
        gender: map['gender'] as String,
        phone: map['phone'] as String,
        diagnosis: map['diagnosis'] as String,
        notes: (map['notes'] as String?) ?? '',
        imagePath: map['imagePath'] as String?,
        documentPath: map['documentPath'] as String?,
        createdAt: map['createdAt'] as String,
      );

  Patient copyWith({
    int? id,
    String? name,
    int? age,
    String? gender,
    String? phone,
    String? diagnosis,
    String? notes,
    String? imagePath,
    String? documentPath,
    String? createdAt,
    bool clearImage = false,
    bool clearDocument = false,
  }) => Patient(
        id: id ?? this.id,
        name: name ?? this.name,
        age: age ?? this.age,
        gender: gender ?? this.gender,
        phone: phone ?? this.phone,
        diagnosis: diagnosis ?? this.diagnosis,
        notes: notes ?? this.notes,
        imagePath: clearImage ? null : (imagePath ?? this.imagePath),
        documentPath: clearDocument ? null : (documentPath ?? this.documentPath),
        createdAt: createdAt ?? this.createdAt,
      );
}
