import 'dart:io';
import 'package:flutter/material.dart';
import '../models/patient.dart';
import 'patient_form_screen.dart';

class PatientDetailScreen extends StatefulWidget {
  final Patient patient;
  const PatientDetailScreen({super.key, required this.patient});
  @override
  State<PatientDetailScreen> createState() => _PatientDetailScreenState();
}

class _PatientDetailScreenState extends State<PatientDetailScreen> {
  late Patient _patient;

  @override
  void initState() {
    super.initState();
    _patient = widget.patient;
  }

  Future<void> _edit() async {
    final changed = await Navigator.push<bool>(
      context,
      MaterialPageRoute(builder: (_) => PatientFormScreen(patient: _patient)),
    );
    if (changed == true && mounted) Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    final imageExists = _patient.imagePath != null && File(_patient.imagePath!).existsSync();
    final documentName = _patient.documentPath?.split(Platform.pathSeparator).last;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Patient details', style: TextStyle(fontWeight: FontWeight.w800)),
        actions: [IconButton(onPressed: _edit, icon: const Icon(Icons.edit_outlined), tooltip: 'Edit patient')],
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFF16324F), Color(0xFF245B73)]),
              borderRadius: BorderRadius.circular(24),
            ),
            child: Column(children: [
              CircleAvatar(
                radius: 42,
                backgroundColor: Colors.white,
                backgroundImage: imageExists ? FileImage(File(_patient.imagePath!)) : null,
                child: !imageExists ? Text(_patient.name.isEmpty ? '?' : _patient.name[0].toUpperCase(), style: const TextStyle(fontSize: 30, color: Color(0xFF168A8A), fontWeight: FontWeight.w800)) : null,
              ),
              const SizedBox(height: 14),
              Text(_patient.name, style: const TextStyle(fontSize: 23, color: Colors.white, fontWeight: FontWeight.w800)),
              const SizedBox(height: 5),
              Text('${_patient.age} years • ${_patient.gender}', style: const TextStyle(color: Colors.white70)),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 7),
                decoration: BoxDecoration(color: Colors.white.withValues(alpha: .15), borderRadius: BorderRadius.circular(10)),
                child: Text(_patient.diagnosis, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
              ),
            ]),
          ),
          const SizedBox(height: 22),
          const Text('Contact information', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: Color(0xFF16324F))),
          const SizedBox(height: 12),
          _detailRow(Icons.phone_outlined, 'Phone number', _patient.phone),
          const SizedBox(height: 22),
          const Text('Clinical notes', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: Color(0xFF16324F))),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFFE4EBF0))),
            child: Text(_patient.notes.isEmpty ? 'No clinical notes added.' : _patient.notes, style: const TextStyle(height: 1.5, color: Color(0xFF526779))),
          ),
          const SizedBox(height: 22),
          const Text('Attached files', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: Color(0xFF16324F))),
          const SizedBox(height: 12),
          _detailRow(Icons.image_outlined, 'Patient image', imageExists ? _patient.imagePath!.split(Platform.pathSeparator).last : 'No image attached'),
          if (documentName != null) ...[
            const SizedBox(height: 10),
            _detailRow(Icons.description_outlined, 'Document', documentName),
          ],
          const SizedBox(height: 24),
          FilledButton.icon(onPressed: _edit, icon: const Icon(Icons.edit_outlined), label: const Text('Edit patient details'), style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52))),
        ],
      ),
    );
  }

  Widget _detailRow(IconData icon, String title, String value) => Container(
    padding: const EdgeInsets.all(15),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(15), border: Border.all(color: const Color(0xFFE4EBF0))),
    child: Row(children: [
      Container(width: 42, height: 42, decoration: BoxDecoration(color: const Color(0xFFE7F7F5), borderRadius: BorderRadius.circular(12)), child: Icon(icon, color: const Color(0xFF168A8A))),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(fontSize: 12, color: Color(0xFF718096))),
        const SizedBox(height: 3),
        Text(value, style: const TextStyle(fontWeight: FontWeight.w700, color: Color(0xFF29465F))),
      ])),
    ]),
  );
}
