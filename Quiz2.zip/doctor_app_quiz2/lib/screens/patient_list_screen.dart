import 'dart:io';
import 'package:flutter/material.dart';
import '../database/database_helper.dart';
import '../models/patient.dart';
import 'patient_form_screen.dart';
import 'patient_detail_screen.dart';

class PatientListScreen extends StatefulWidget {
  const PatientListScreen({super.key});
  @override
  State<PatientListScreen> createState() => _PatientListScreenState();
}

class _PatientListScreenState extends State<PatientListScreen> {
  final _searchController = TextEditingController();
  List<Patient> _patients = [];
  int _total = 0;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadPatients();
    _searchController.addListener(_loadPatients);
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadPatients() async {
    final patients = await DatabaseHelper.instance.getPatients(search: _searchController.text);
    final total = await DatabaseHelper.instance.countPatients();
    if (!mounted) return;
    setState(() {
      _patients = patients;
      _total = total;
      _loading = false;
    });
  }

  Future<void> _openForm([Patient? patient]) async {
    final saved = await Navigator.push<bool>(
      context,
      MaterialPageRoute(builder: (_) => PatientFormScreen(patient: patient)),
    );
    if (saved == true) _loadPatients();
  }

  Future<void> _deletePatient(Patient patient) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete patient?'),
        content: Text('Remove ${patient.name} from your patient records? This cannot be undone.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: const Color(0xFFD9485F)),
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (confirmed == true && patient.id != null) {
      await DatabaseHelper.instance.deletePatient(patient.id!);
      _loadPatients();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Patient record deleted')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('CarePoint', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w800)),
          Text('DOCTOR WORKSPACE', style: TextStyle(fontSize: 10, letterSpacing: 1.6, color: Color(0xFF718096))),
        ]),
        actions: [
          IconButton(
            tooltip: 'Refresh patients',
            onPressed: _loadPatients,
            icon: const Icon(Icons.refresh_rounded),
          ),
          const SizedBox(width: 8),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openForm(),
        icon: const Icon(Icons.person_add_alt_1_rounded),
        label: const Text('Add patient'),
      ),
      body: RefreshIndicator(
        onRefresh: _loadPatients,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 100),
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [Color(0xFF16324F), Color(0xFF245B73)]),
                borderRadius: BorderRadius.circular(24),
              ),
              child: Row(children: [
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('Good day, Doctor 👋', style: TextStyle(color: Colors.white70, fontSize: 13)),
                  const SizedBox(height: 8),
                  const Text('Your patients,\\none place.', style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w800, height: 1.2)),
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(color: Colors.white.withValues(alpha: .14), borderRadius: BorderRadius.circular(12)),
                    child: Text('$_total total patient${_total == 1 ? '' : 's'}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
                  ),
                ])),
                Container(
                  width: 74, height: 74,
                  decoration: BoxDecoration(color: Colors.white.withValues(alpha: .12), shape: BoxShape.circle),
                  child: const Icon(Icons.medical_services_rounded, color: Colors.white, size: 39),
                ),
              ]),
            ),
            const SizedBox(height: 24),
            const Text('Patient records', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800, color: Color(0xFF16324F))),
            const SizedBox(height: 4),
            const Text('Search, review and manage your patients', style: TextStyle(color: Color(0xFF718096))),
            const SizedBox(height: 16),
            TextField(
              controller: _searchController,
              decoration: const InputDecoration(
                hintText: 'Search name, diagnosis or phone',
                prefixIcon: Icon(Icons.search_rounded),
              ),
            ),
            const SizedBox(height: 16),
            if (_loading)
              const Center(child: Padding(padding: EdgeInsets.all(32), child: CircularProgressIndicator()))
            else if (_patients.isEmpty)
              Container(
                padding: const EdgeInsets.all(28),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xFFE4EBF0))),
                child: Column(children: [
                  const Icon(Icons.folder_open_rounded, size: 48, color: Color(0xFF1AA6A6)),
                  const SizedBox(height: 12),
                  Text(_searchController.text.isEmpty ? 'No patients yet' : 'No matching patients', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 6),
                  const Text('Add a patient to start building your local records.', textAlign: TextAlign.center, style: TextStyle(color: Color(0xFF718096))),
                  const SizedBox(height: 14),
                  OutlinedButton.icon(onPressed: () => _openForm(), icon: const Icon(Icons.add), label: const Text('Add first patient')),
                ]),
              )
            else
              ..._patients.map((patient) => _patientCard(patient)),
          ],
        ),
      ),
    );
  }

  Widget _patientCard(Patient patient) {
    return Card(
      elevation: 0,
      color: Colors.white,
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18), side: const BorderSide(color: Color(0xFFE4EBF0))),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () async {
          await Navigator.push(context, MaterialPageRoute(builder: (_) => PatientDetailScreen(patient: patient)));
          _loadPatients();
        },
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(children: [
            CircleAvatar(
              radius: 27,
              backgroundColor: const Color(0xFFE0F5F3),
              backgroundImage: patient.imagePath != null && File(patient.imagePath!).existsSync() ? FileImage(File(patient.imagePath!)) : null,
              child: patient.imagePath == null || !File(patient.imagePath!).existsSync()
                  ? Text(patient.name.isEmpty ? '?' : patient.name[0].toUpperCase(), style: const TextStyle(color: Color(0xFF168A8A), fontWeight: FontWeight.w800, fontSize: 20))
                  : null,
            ),
            const SizedBox(width: 13),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(patient.name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: Color(0xFF16324F))),
              const SizedBox(height: 4),
              Text('${patient.age} years • ${patient.gender}', style: const TextStyle(color: Color(0xFF718096), fontSize: 12)),
              const SizedBox(height: 6),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
                decoration: BoxDecoration(color: const Color(0xFFE7F7F5), borderRadius: BorderRadius.circular(8)),
                child: Text(patient.diagnosis, style: const TextStyle(color: Color(0xFF168A8A), fontSize: 11, fontWeight: FontWeight.w700)),
              ),
            ])),
            PopupMenuButton<String>(
              onSelected: (value) {
                if (value == 'edit') _openForm(patient);
                if (value == 'delete') _deletePatient(patient);
              },
              itemBuilder: (_) => const [
                PopupMenuItem(value: 'edit', child: ListTile(leading: Icon(Icons.edit_outlined), title: Text('Edit'), contentPadding: EdgeInsets.zero)),
                PopupMenuItem(value: 'delete', child: ListTile(leading: Icon(Icons.delete_outline, color: Color(0xFFD9485F)), title: Text('Delete'), contentPadding: EdgeInsets.zero)),
              ],
            ),
          ]),
        ),
      ),
    );
  }
}
