import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../database/database_helper.dart';
import '../models/patient.dart';

class PatientFormScreen extends StatefulWidget {
  final Patient? patient;
  const PatientFormScreen({super.key, this.patient});
  @override
  State<PatientFormScreen> createState() => _PatientFormScreenState();
}

class _PatientFormScreenState extends State<PatientFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _age = TextEditingController();
  final _phone = TextEditingController();
  final _diagnosis = TextEditingController();
  final _notes = TextEditingController();
  String _gender = 'Male';
  String? _imagePath;
  String? _documentPath;
  bool _saving = false;

  bool get _editing => widget.patient != null;

  @override
  void initState() {
    super.initState();
    final p = widget.patient;
    if (p != null) {
      _name.text = p.name;
      _age.text = p.age.toString();
      _phone.text = p.phone;
      _diagnosis.text = p.diagnosis;
      _notes.text = p.notes;
      _gender = p.gender;
      _imagePath = p.imagePath;
      _documentPath = p.documentPath;
    }
  }

  @override
  void dispose() {
    _name.dispose();
    _age.dispose();
    _phone.dispose();
    _diagnosis.dispose();
    _notes.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    final picked = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 85);
    if (picked != null) setState(() => _imagePath = picked.path);
  }

  Future<void> _pickDocument() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf', 'jpg', 'jpeg', 'png', 'doc', 'docx'],
    );
    if (result != null && result.files.single.path != null) {
      setState(() => _documentPath = result.files.single.path);
    }
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);
    final old = widget.patient;
    final patient = Patient(
      id: old?.id,
      name: _name.text.trim(),
      age: int.parse(_age.text.trim()),
      gender: _gender,
      phone: _phone.text.trim(),
      diagnosis: _diagnosis.text.trim(),
      notes: _notes.text.trim(),
      imagePath: _imagePath,
      documentPath: _documentPath,
      createdAt: old?.createdAt ?? DateTime.now().toIso8601String(),
    );
    if (_editing) {
      await DatabaseHelper.instance.updatePatient(patient);
    } else {
      await DatabaseHelper.instance.insertPatient(patient);
    }
    if (!mounted) return;
    Navigator.pop(context, true);
  }

  Widget _field(String label, TextEditingController controller, {String? hint, int maxLines = 1, TextInputType? keyboardType, String? Function(String?)? validator}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 15),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: const TextStyle(fontWeight: FontWeight.w700, color: Color(0xFF29465F))),
        const SizedBox(height: 8),
        TextFormField(
          controller: controller,
          maxLines: maxLines,
          keyboardType: keyboardType,
          validator: validator ?? (value) => value == null || value.trim().isEmpty ? 'Please enter $label'.toLowerCase() : null,
          decoration: InputDecoration(hintText: hint ?? 'Enter $label'),
        ),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_editing ? 'Edit patient' : 'Add patient', style: const TextStyle(fontWeight: FontWeight.w800))),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 28),
          children: [
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(color: const Color(0xFFE7F7F5), borderRadius: BorderRadius.circular(18)),
              child: const Row(children: [
                Icon(Icons.verified_user_outlined, color: Color(0xFF168A8A), size: 28),
                SizedBox(width: 12),
                Expanded(child: Text('Patient information is saved locally on this device.', style: TextStyle(color: Color(0xFF286B6B), fontWeight: FontWeight.w600))),
              ]),
            ),
            const SizedBox(height: 22),
            _field('Full name', _name, hint: 'e.g. Ayesha Khan'),
            Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Expanded(child: _field('Age', _age, hint: 'e.g. 28', keyboardType: TextInputType.number, validator: (v) {
                final age = int.tryParse((v ?? '').trim());
                return age == null || age < 0 || age > 130 ? 'Enter a valid age' : null;
              })),
              const SizedBox(width: 12),
              Expanded(child: Padding(
                padding: const EdgeInsets.only(bottom: 15),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('Gender', style: TextStyle(fontWeight: FontWeight.w700, color: Color(0xFF29465F))),
                  const SizedBox(height: 8),
                  DropdownButtonFormField<String>(
                    value: _gender,
                    decoration: const InputDecoration(),
                    items: const ['Male', 'Female', 'Other'].map((g) => DropdownMenuItem(value: g, child: Text(g))).toList(),
                    onChanged: (value) => setState(() => _gender = value ?? 'Male'),
                  ),
                ]),
              )),
            ]),
            _field('Phone number', _phone, hint: '+92 300 1234567', keyboardType: TextInputType.phone),
            _field('Diagnosis', _diagnosis, hint: 'e.g. Seasonal allergy'),
            _field('Clinical notes', _notes, hint: 'Symptoms, treatment, follow-up...', maxLines: 3, validator: (_) => null),
            const Text('Patient files', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: Color(0xFF16324F))),
            const SizedBox(height: 10),
            OutlinedButton.icon(
              onPressed: _pickImage,
              icon: const Icon(Icons.add_a_photo_outlined),
              label: Text(_imagePath == null ? 'Choose patient image' : 'Image selected: ${_imagePath!.split(Platform.pathSeparator).last}'),
              style: OutlinedButton.styleFrom(padding: const EdgeInsets.all(15), alignment: Alignment.centerLeft),
            ),
            const SizedBox(height: 10),
            OutlinedButton.icon(
              onPressed: _pickDocument,
              icon: const Icon(Icons.attach_file_rounded),
              label: Text(_documentPath == null ? 'Attach document (PDF / image / Word)' : 'File: ${_documentPath!.split(Platform.pathSeparator).last}'),
              style: OutlinedButton.styleFrom(padding: const EdgeInsets.all(15), alignment: Alignment.centerLeft),
            ),
            if (_documentPath != null) ...[
              const SizedBox(height: 8),
              Text('Attached: ${_documentPath!.split(Platform.pathSeparator).last}', style: const TextStyle(color: Color(0xFF168A8A))),
              Align(alignment: Alignment.centerLeft, child: TextButton.icon(
                onPressed: () => setState(() => _documentPath = null),
                icon: const Icon(Icons.close),
                label: const Text('Remove attachment'),
              )),
            ],
            const SizedBox(height: 24),
            FilledButton.icon(
              onPressed: _saving ? null : _save,
              icon: Icon(_editing ? Icons.save_outlined : Icons.person_add_alt_1_rounded),
              label: Text(_saving ? 'Saving...' : _editing ? 'Save changes' : 'Save patient'),
              style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(54), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15))),
            ),
          ],
        ),
      ),
    );
  }
}
