import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import '../models/patient.dart';

class DatabaseHelper {
  DatabaseHelper._();
  static final DatabaseHelper instance = DatabaseHelper._();
  static Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    final dbPath = await getDatabasesPath();
    return openDatabase(
      join(dbPath, 'carepoint_patients.db'),
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE patients(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            age INTEGER NOT NULL,
            gender TEXT NOT NULL,
            phone TEXT NOT NULL,
            diagnosis TEXT NOT NULL,
            notes TEXT NOT NULL DEFAULT '',
            imagePath TEXT,
            documentPath TEXT,
            createdAt TEXT NOT NULL
          )
        ''');
      },
    );
  }

  Future<List<Patient>> getPatients({String search = ''}) async {
    final db = await database;
    final rows = search.trim().isEmpty
        ? await db.query('patients', orderBy: 'id DESC')
        : await db.query(
            'patients',
            where: 'name LIKE ? OR diagnosis LIKE ? OR phone LIKE ?',
            whereArgs: ['%$search%', '%$search%', '%$search%'],
            orderBy: 'id DESC',
          );
    return rows.map(Patient.fromMap).toList();
  }

  Future<int> insertPatient(Patient patient) async {
    final db = await database;
    return db.insert('patients', patient.toMap()..remove('id'));
  }

  Future<int> updatePatient(Patient patient) async {
    final db = await database;
    return db.update(
      'patients',
      patient.toMap()..remove('id'),
      where: 'id = ?',
      whereArgs: [patient.id],
    );
  }

  Future<int> deletePatient(int id) async {
    final db = await database;
    return db.delete('patients', where: 'id = ?', whereArgs: [id]);
  }

  Future<int> countPatients() async {
    final db = await database;
    final result = await db.rawQuery('SELECT COUNT(*) AS total FROM patients');
    return Sqflite.firstIntValue(result) ?? 0;
  }
}
