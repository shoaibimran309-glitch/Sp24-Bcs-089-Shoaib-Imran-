# CSC303 — Mobile Application Development
## Quiz 1: Basic Flutter UI Widgets

This Flutter app demonstrates the widgets requested in the Quiz 1 PDF:
- Text heading
- Two TextFields (student name and registration number)
- Radio buttons for gender
- Checkboxes for hobbies
- Option list (Morning, Afternoon, Evening)
- Selection list (Flutter, Dart, Firebase)
- Department dropdown (CS, IT, SE, AI)
- Simple button and Submit button

## Run the app
1. Install Flutter and Android Studio.
2. Open this folder in Android Studio or VS Code.
3. Run `flutter pub get`.
4. Start an emulator or connect an Android device.
5. Run `flutter run`.

## GitHub submission
Upload the `lib` folder, `pubspec.yaml`, and at least two real screenshots from your running emulator to the shared repository's `Quiz 1` folder.

## Screenshots note
The images in `screenshots/` are illustrative UI previews, not captured from a running emulator. Replace them with actual screenshots after running the app before final submission.
