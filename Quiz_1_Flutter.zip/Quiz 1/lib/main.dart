import 'package:flutter/material.dart';

void main() {
  runApp(const QuizOneApp());
}

class QuizOneApp extends StatelessWidget {
  const QuizOneApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Quiz 1 - Student Registration',
      home: const RegistrationScreen(),
    );
  }
}

class RegistrationScreen extends StatefulWidget {
  const RegistrationScreen({super.key});

  @override
  State<RegistrationScreen> createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends State<RegistrationScreen> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController registrationController = TextEditingController();

  String gender = 'Male';
  bool reading = false;
  bool sports = false;
  String selectedOption = 'Morning';
  String selectedItem = 'Flutter';
  String department = 'CS';
  String message = '';

  @override
  void dispose() {
    nameController.dispose();
    registrationController.dispose();
    super.dispose();
  }

  void showSubmission() {
    setState(() {
      final studentName = nameController.text.trim().isEmpty
          ? 'Not entered'
          : nameController.text.trim();
      final regNo = registrationController.text.trim().isEmpty
          ? 'Not entered'
          : registrationController.text.trim();
      message = 'Submitted: $studentName | $regNo | $gender | $department';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Quiz 1: Basic Flutter UI Widgets')),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const Text(
                'Student Registration Form',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 12),

              SizedBox(
                width: 320,
                child: TextField(
                  controller: nameController,
                  decoration: const InputDecoration(
                    labelText: 'Student Name',
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              const SizedBox(height: 10),

              SizedBox(
                width: 320,
                child: TextField(
                  controller: registrationController,
                  decoration: const InputDecoration(
                    labelText: 'Registration Number',
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              const SizedBox(height: 8),

              const Text('Gender'),
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Radio<String>(
                    value: 'Male',
                    groupValue: gender,
                    onChanged: (value) => setState(() => gender = value!),
                  ),
                  const Text('Male'),
                  Radio<String>(
                    value: 'Female',
                    groupValue: gender,
                    onChanged: (value) => setState(() => gender = value!),
                  ),
                  const Text('Female'),
                ],
              ),

              const Text('Hobbies'),
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Checkbox(
                    value: reading,
                    onChanged: (value) => setState(() => reading = value!),
                  ),
                  const Text('Reading'),
                  Checkbox(
                    value: sports,
                    onChanged: (value) => setState(() => sports = value!),
                  ),
                  const Text('Sports'),
                ],
              ),

              const Text('Option List'),
              DropdownButton<String>(
                value: selectedOption,
                items: const [
                  DropdownMenuItem(value: 'Morning', child: Text('Morning')),
                  DropdownMenuItem(value: 'Afternoon', child: Text('Afternoon')),
                  DropdownMenuItem(value: 'Evening', child: Text('Evening')),
                ],
                onChanged: (value) => setState(() => selectedOption = value!),
              ),

              const Text('Selection List (select one item)'),
              Column(
                mainAxisSize: MainAxisSize.min,
                children: ['Flutter', 'Dart', 'Firebase']
                    .map(
                      (item) => SizedBox(
                        width: 220,
                        child: RadioListTile<String>(
                          dense: true,
                          contentPadding: EdgeInsets.zero,
                          title: Text(item),
                          value: item,
                          groupValue: selectedItem,
                          onChanged: (value) =>
                              setState(() => selectedItem = value!),
                        ),
                      ),
                    )
                    .toList(),
              ),

              const Text('Department'),
              DropdownButton<String>(
                value: department,
                items: const [
                  DropdownMenuItem(value: 'CS', child: Text('CS')),
                  DropdownMenuItem(value: 'IT', child: Text('IT')),
                  DropdownMenuItem(value: 'SE', child: Text('SE')),
                  DropdownMenuItem(value: 'AI', child: Text('AI')),
                ],
                onChanged: (value) => setState(() => department = value!),
              ),

              Wrap(
                alignment: WrapAlignment.center,
                spacing: 12,
                children: [
                  ElevatedButton(
                    onPressed: () {
                      setState(() => message = 'Simple button pressed.');
                    },
                    child: const Text('Click Me'),
                  ),
                  ElevatedButton(
                    onPressed: showSubmission,
                    child: const Text('Submit'),
                  ),
                ],
              ),
              if (message.isNotEmpty) ...[
                const SizedBox(height: 8),
                Text(message, textAlign: TextAlign.center),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
