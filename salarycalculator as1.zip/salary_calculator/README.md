# Salary Calculator – Flutter

A beginner-friendly Flutter/Dart salary calculator that estimates take-home salary from gross salary, allowances, tax rate, and other deductions.

## Features

- Gross salary input
- Allowances input
- Other deductions input
- Tax percentage input
- Monthly working hours input
- Net salary calculation
- Tax amount and total deductions
- Estimated hourly rate
- Calculate and Reset buttons
- Responsive Material 3 UI

## Formula

```text
Taxable Salary = Gross Salary + Allowances
Tax Amount = Taxable Salary × Tax Rate / 100
Total Deductions = Tax Amount + Other Deductions
Net Salary = Taxable Salary − Total Deductions
Hourly Rate = Net Salary / Monthly Hours
```

## Requirements

- Flutter SDK
- Dart SDK compatible with the `pubspec.yaml` environment
- Android Studio or VS Code
- Android SDK for Android builds

## Run the project

```bash
flutter pub get
flutter run
```

For an Android APK:

```bash
flutter build apk --release
```

The APK will be generated under:

```text
build/app/outputs/flutter-apk/app-release.apk
```

## Project structure

```text
salary_calculator/
├── android/
│   ├── app/
│   │   ├── build.gradle
│   │   └── src/main/
│   │       ├── AndroidManifest.xml
│   │       └── kotlin/com/example/salarycalculator/MainActivity.kt
│   └── build.gradle
├── lib/
│   └── main.dart
├── screenshots/
├── .gitignore
├── analysis_options.yaml
├── pubspec.yaml
└── README.md
```

## Important

The tax percentage in this app is a user-entered estimate. It is not a country-specific payroll/tax calculator. For real payroll use, replace the simple percentage formula with the applicable tax rules for the target country and tax year.

> **Android tooling note:** Flutter normally creates `android/local.properties` for your machine because it contains your local Flutter SDK path. Do not commit that file. If you open this project in Android Studio, make sure the Flutter and Dart plugins are installed and the Flutter SDK is configured.
