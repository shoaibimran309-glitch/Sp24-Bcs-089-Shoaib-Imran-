import 'package:flutter/material.dart';

void main() {
  runApp(const SalaryCalculatorApp());
}

class SalaryCalculatorApp extends StatelessWidget {
  const SalaryCalculatorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Salary Calculator',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF2563EB)),
        scaffoldBackgroundColor: const Color(0xFFF5F7FB),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xFFE2E8F0)),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xFFE2E8F0)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xFF2563EB), width: 2),
          ),
        ),
      ),
      home: const SalaryCalculatorPage(),
    );
  }
}

class SalaryCalculatorPage extends StatefulWidget {
  const SalaryCalculatorPage({super.key});

  @override
  State<SalaryCalculatorPage> createState() => _SalaryCalculatorPageState();
}

class _SalaryCalculatorPageState extends State<SalaryCalculatorPage> {
  final _grossController = TextEditingController();
  final _allowanceController = TextEditingController();
  final _deductionController = TextEditingController();
  final _taxController = TextEditingController(text: '10');
  final _hoursController = TextEditingController(text: '160');

  double _netSalary = 0;
  double _taxAmount = 0;
  double _totalDeductions = 0;
  double _hourlyRate = 0;
  bool _calculated = false;

  double _value(TextEditingController controller) =>
      double.tryParse(controller.text.trim()) ?? 0;

  void _calculate() {
    final gross = _value(_grossController);
    final allowance = _value(_allowanceController);
    final deduction = _value(_deductionController);
    final taxRate = _value(_taxController).clamp(0, 100).toDouble();
    final hours = _value(_hoursController);

    final taxableSalary = gross + allowance;
    final tax = taxableSalary * taxRate / 100;
    final totalDeductions = tax + deduction;
    final net = taxableSalary - totalDeductions;
    final hourly = hours > 0 ? net / hours : 0;

    setState(() {
      _taxAmount = tax;
      _totalDeductions = totalDeductions;
      _netSalary = net < 0 ? 0 : net;
      _hourlyRate = hourly < 0 ? 0 : hourly;
      _calculated = true;
    });
  }

  void _reset() {
    _grossController.clear();
    _allowanceController.clear();
    _deductionController.clear();
    _taxController.text = '10';
    _hoursController.text = '160';
    setState(() {
      _netSalary = 0;
      _taxAmount = 0;
      _totalDeductions = 0;
      _hourlyRate = 0;
      _calculated = false;
    });
  }

  String _money(double value) => value.toStringAsFixed(2);

  @override
  void dispose() {
    _grossController.dispose();
    _allowanceController.dispose();
    _deductionController.dispose();
    _taxController.dispose();
    _hoursController.dispose();
    super.dispose();
  }

  Widget _field({
    required String label,
    required String hint,
    required TextEditingController controller,
    String? suffix,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: TextField(
        controller: controller,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          suffixText: suffix,
          prefixIcon: const Icon(Icons.payments_outlined),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Salary Calculator', style: TextStyle(fontWeight: FontWeight.w700)),
        centerTitle: true,
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.white,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF2563EB), Color(0xFF1D4ED8)],
                  ),
                  borderRadius: BorderRadius.circular(22),
                ),
                child: const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(Icons.account_balance_wallet_outlined, color: Colors.white, size: 34),
                    SizedBox(height: 12),
                    Text('Calculate your take-home salary',
                        style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
                    SizedBox(height: 6),
                    Text('Enter your salary details and get an instant estimate.',
                        style: TextStyle(color: Colors.white70, fontSize: 14)),
                  ],
                ),
              ),
              const SizedBox(height: 18),
              Card(
                elevation: 0,
                color: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                child: Padding(
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const Text('Salary Details', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 16),
                      _field(label: 'Gross Salary', hint: 'e.g. 100000', controller: _grossController),
                      _field(label: 'Allowances', hint: 'e.g. 10000', controller: _allowanceController),
                      _field(label: 'Other Deductions', hint: 'e.g. 5000', controller: _deductionController),
                      Row(
                        children: [
                          Expanded(child: _field(label: 'Tax Rate', hint: '10', controller: _taxController, suffix: '%')),
                          const SizedBox(width: 12),
                          Expanded(child: _field(label: 'Monthly Hours', hint: '160', controller: _hoursController)),
                        ],
                      ),
                      Row(
                        children: [
                          Expanded(
                            child: FilledButton.icon(
                              onPressed: _calculate,
                              icon: const Icon(Icons.calculate_outlined),
                              label: const Text('Calculate'),
                              style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 15)),
                            ),
                          ),
                          const SizedBox(width: 10),
                          OutlinedButton.icon(
                            onPressed: _reset,
                            icon: const Icon(Icons.refresh),
                            label: const Text('Reset'),
                            style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 14)),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              if (_calculated) ...[
                const SizedBox(height: 18),
                Card(
                  elevation: 0,
                  color: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                  child: Padding(
                    padding: const EdgeInsets.all(18),
                    child: Column(
                      children: [
                        const Align(
                          alignment: Alignment.centerLeft,
                          child: Text('Calculation Result', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                        ),
                        const SizedBox(height: 14),
                        Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            color: const Color(0xFFEFF6FF),
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Column(
                            children: [
                              const Text('NET SALARY', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 1.2)),
                              const SizedBox(height: 6),
                              Text(_money(_netSalary), style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w800, color: Color(0xFF1D4ED8))),
                            ],
                          ),
                        ),
                        const SizedBox(height: 14),
                        _resultRow('Tax Amount', _money(_taxAmount)),
                        _resultRow('Total Deductions', _money(_totalDeductions)),
                        _resultRow('Hourly Rate', _money(_hourlyRate)),
                      ],
                    ),
                  ),
                ),
              ],
              const SizedBox(height: 18),
              const Text('Note: This is an estimate. Actual payroll taxes depend on your country, tax year, and employer rules.',
                  textAlign: TextAlign.center, style: TextStyle(color: Color(0xFF64748B), fontSize: 12)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _resultRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 9),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: Color(0xFF475569))),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}
