package com.example.salarycalculator

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
