import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/document_provider.dart';
import '../widgets/document_card.dart';
import '../widgets/empty_state_widget.dart';
import '../utils/constants.dart';
import 'scanner_view.dart';

class LibraryView extends StatefulWidget {
  const LibraryView({Key? key}) : super(key: key);

  @override
  State<LibraryView> createState() => _LibraryViewState();
}

class _LibraryViewState extends State<LibraryView> {
  final TextEditingController _searchController = TextEditingController();

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final docProvider = context.watch<DocumentProvider>();
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('PDF Library'),
        actions: [
          // Sort Menu
          PopupMenuButton<String>(
            icon: const Icon(Icons.sort_rounded),
            tooltip: 'Sort Documents',
            onSelected: (val) => docProvider.setSortBy(val),
            itemBuilder: (ctx) => [
              const PopupMenuItem(value: 'last_opened_desc', child: Text('Recently Opened')),
              const PopupMenuItem(value: 'date_desc', child: Text('Recently Added')),
              const PopupMenuItem(value: 'title_asc', child: Text('Title (A-Z)')),
              const PopupMenuItem(value: 'title_desc', child: Text('Title (Z-A)')),
              const PopupMenuItem(value: 'size_desc', child: Text('Largest File Size')),
              const PopupMenuItem(value: 'progress_desc', child: Text('Reading Progress')),
            ],
          ),
          // View Mode Toggle (Grid / List)
          IconButton(
            icon: Icon(docProvider.isGridView ? Icons.view_list_rounded : Icons.grid_view_rounded),
            tooltip: docProvider.isGridView ? 'List View' : 'Grid View',
            onPressed: () => docProvider.toggleViewMode(),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: Column(
        children: [
          // Search Bar
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
            child: TextField(
              controller: _searchController,
              onChanged: (val) => docProvider.setSearchQuery(val),
              decoration: InputDecoration(
                hintText: 'Search by title, tags, or description...',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear, size: 18),
                        onPressed: () {
                          _searchController.clear();
                          docProvider.setSearchQuery('');
                        },
                      )
                    : null,
              ),
            ),
          ),

          // Tag Filter Chips Carousel
          SizedBox(
            height: 42,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              children: AppConstants.defaultTags.map((tag) {
                final isSelected = docProvider.selectedTag == tag;
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: FilterChip(
                    label: Text(tag),
                    selected: isSelected,
                    selectedColor: theme.colorScheme.primary.withOpacity(0.15),
                    checkmarkColor: theme.colorScheme.primary,
                    labelStyle: TextStyle(
                      color: isSelected ? theme.colorScheme.primary : theme.colorScheme.onSurface,
                      fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                      fontSize: 12,
                    ),
                    onSelected: (_) => docProvider.setSelectedTag(tag),
                  ),
                );
              }).toList(),
            ),
          ),
          const SizedBox(height: 8),

          // Documents List or Grid
          Expanded(
            child: docProvider.isLoading
                ? const Center(child: CircularProgressIndicator())
                : docProvider.documents.isEmpty
                    ? EmptyStateWidget(
                        icon: Icons.picture_as_pdf_outlined,
                        title: docProvider.searchQuery.isNotEmpty
                            ? 'No Matching Documents'
                            : 'No PDFs in Library',
                        message: docProvider.searchQuery.isNotEmpty
                            ? 'Try searching with a different term or clear tag filters.'
                            : 'Import PDF files from your device storage or use the scanner to create new ones.',
                        buttonText: docProvider.searchQuery.isNotEmpty ? null : 'Import PDF from Device',
                        onButtonPressed: () => docProvider.importPdfs(),
                      )
                    : RefreshIndicator(
                        onRefresh: () => docProvider.loadDocuments(),
                        child: docProvider.isGridView
                            ? GridView.builder(
                                padding: const EdgeInsets.all(16),
                                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                                  crossAxisCount: 2,
                                  childAspectRatio: 0.82,
                                  crossAxisSpacing: 12,
                                  mainAxisSpacing: 12,
                                ),
                                itemCount: docProvider.documents.length,
                                itemBuilder: (ctx, idx) => DocumentCard(
                                  document: docProvider.documents[idx],
                                  isGrid: true,
                                ),
                              )
                            : ListView.builder(
                                padding: const EdgeInsets.fromLTRB(16, 8, 16, 80),
                                itemCount: docProvider.documents.length,
                                itemBuilder: (ctx, idx) => DocumentCard(
                                  document: docProvider.documents[idx],
                                  isGrid: false,
                                ),
                              ),
                      ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showAddOptions(context),
        icon: const Icon(Icons.add),
        label: const Text('Add Document'),
      ),
    );
  }

  void _showAddOptions(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Text(
                  'Add Document to Library',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),
              const SizedBox(height: 8),
              ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.blue.shade50,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(Icons.file_open_rounded, color: Colors.blue),
                ),
                title: const Text('Import PDF from Device'),
                subtitle: const Text('Browse and import local PDF files'),
                onTap: () {
                  Navigator.of(ctx).pop();
                  context.read<DocumentProvider>().importPdfs();
                },
              ),
              ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.green.shade50,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(Icons.document_scanner_rounded, color: Colors.green),
                ),
                title: const Text('Scan Physical Document'),
                subtitle: const Text('Use camera to scan, crop & convert to PDF'),
                onTap: () {
                  Navigator.of(ctx).pop();
                  Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => const ScannerView()),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
