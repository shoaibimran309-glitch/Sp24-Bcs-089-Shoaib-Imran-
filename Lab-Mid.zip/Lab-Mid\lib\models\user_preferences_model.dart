import 'package:flutter/material.dart';

/// Model representing user preferences and reading customization.
class UserPreferencesModel {
  final ThemeMode themeMode;
  final int readingBgColorValue;
  final String notificationSound;
  final int dailyGoalMinutes;
  final String reminderTime; // Format "HH:mm" e.g., "20:00"
  final bool remindersEnabled;

  UserPreferencesModel({
    this.themeMode = ThemeMode.system,
    this.readingBgColorValue = 0xFFFFFFFF, // Default white
    this.notificationSound = 'default',
    this.dailyGoalMinutes = 20,
    this.reminderTime = '20:00',
    this.remindersEnabled = true,
  });

  Color get readingBgColor => Color(readingBgColorValue);

  UserPreferencesModel copyWith({
    ThemeMode? themeMode,
    int? readingBgColorValue,
    String? notificationSound,
    int? dailyGoalMinutes,
    String? reminderTime,
    bool? remindersEnabled,
  }) {
    return UserPreferencesModel(
      themeMode: themeMode ?? this.themeMode,
      readingBgColorValue: readingBgColorValue ?? this.readingBgColorValue,
      notificationSound: notificationSound ?? this.notificationSound,
      dailyGoalMinutes: dailyGoalMinutes ?? this.dailyGoalMinutes,
      reminderTime: reminderTime ?? this.reminderTime,
      remindersEnabled: remindersEnabled ?? this.remindersEnabled,
    );
  }

  Map<String, String> toMap() {
    return {
      'theme_mode': themeMode.name,
      'reading_bg_color': readingBgColorValue.toString(),
      'notification_sound': notificationSound,
      'daily_goal_minutes': dailyGoalMinutes.toString(),
      'reminder_time': reminderTime,
      'reminders_enabled': remindersEnabled ? '1' : '0',
    };
  }

  factory UserPreferencesModel.fromMap(Map<String, String> map) {
    ThemeMode mode = ThemeMode.system;
    if (map['theme_mode'] == 'light') mode = ThemeMode.light;
    if (map['theme_mode'] == 'dark') mode = ThemeMode.dark;

    return UserPreferencesModel(
      themeMode: mode,
      readingBgColorValue: int.tryParse(map['reading_bg_color'] ?? '') ?? 0xFFFFFFFF,
      notificationSound: map['notification_sound'] ?? 'default',
      dailyGoalMinutes: int.tryParse(map['daily_goal_minutes'] ?? '') ?? 20,
      reminderTime: map['reminder_time'] ?? '20:00',
      remindersEnabled: (map['reminders_enabled'] ?? '1') == '1',
    );
  }
}
