import 'dart:io';
import 'package:flutter/foundation.dart';
import '../models/document_model.dart';
import '../database/db_helper.dart';
import '../services/pdf_service.dart';
import '../services/notification_service.dart';

class DocumentProvider extends ChangeNotifier {
  List<DocumentModel> _documents = [];
  bool _isLoading = false;
  String _searchQuery = '';
  String _selectedTag = 'All';
  String _sortBy = 'last_opened_desc';
  bool _isGridView = false;

  List<DocumentModel> get documents => _documents;
  bool get isLoading => _isLoading;
  String get searchQuery => _searchQuery;
  String get selectedTag => _selectedTag;
  String get sortBy => _sortBy;
  bool get isGridView => _isGridView;

  List<DocumentModel> get favoriteDocuments =>
      _documents.where((doc) => doc.isFavorite).toList();

  /// Initialize and load documents from SQLite
  Future<void> loadDocuments() async {
    _isLoading = true;
    notifyListeners();

    try {
      // Check if DB is completely empty on first launch and preload sample document
      final allDocs = await DatabaseHelper.instance.getAllDocuments();
      if (allDocs.isEmpty) {
        await PdfService.preloadSampleDocument();
      }

      _documents = await DatabaseHelper.instance.getAllDocuments(
        searchQuery: _searchQuery,
        tag: _selectedTag,
        sortBy: _sortBy,
      );
    } catch (e) {
      debugPrint('Error loading documents: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  void setSearchQuery(String query) {
    _searchQuery = query;
    loadDocuments();
  }

  void setSelectedTag(String tag) {
    _selectedTag = tag;
    loadDocuments();
  }

  void setSortBy(String sortBy) {
    _sortBy = sortBy;
    loadDocuments();
  }

  void toggleViewMode() {
    _isGridView = !_isGridView;
    notifyListeners();
  }

  /// Pick and import PDFs from storage
  Future<int> importPdfs() async {
    try {
      final imported = await PdfService.pickPdfsFromDevice();
      if (imported.isNotEmpty) {
        await loadDocuments();
        for (var doc in imported) {
          await NotificationService.instance.showDocumentAddedNotification(doc.title);
        }
        return imported.length;
      }
    } catch (e) {
      debugPrint('Error importing PDFs: $e');
    }
    return 0;
  }

  /// Add a newly scanned PDF document
  Future<void> addScannedDocument(DocumentModel doc) async {
    await NotificationService.instance.showDocumentAddedNotification(doc.title);
    await loadDocuments();
  }

  /// Toggle document favorite status
  Future<void> toggleFavorite(DocumentModel doc) async {
    final newStatus = !doc.isFavorite;
    await DatabaseHelper.instance.toggleFavorite(doc.id!, newStatus);

    // Update in-memory list immediately
    final index = _documents.indexWhere((d) => d.id == doc.id);
    if (index != -1) {
      _documents[index] = _documents[index].copyWith(isFavorite: newStatus);
      notifyListeners();
    }
  }

  /// Update document metadata (title, tags, description)
  Future<void> updateMetadata({
    required int id,
    required String title,
    required String tags,
    required String description,
  }) async {
    await DatabaseHelper.instance.updateDocumentMetadata(id, title, tags, description);
    await loadDocuments();
  }

  /// Delete document and its underlying file
  Future<void> deleteDocument(DocumentModel doc) async {
    if (doc.id != null) {
      await DatabaseHelper.instance.deleteDocument(doc.id!);
      try {
        final file = File(doc.filePath);
        if (await file.exists()) {
          await file.delete();
        }
      } catch (_) {}
      await loadDocuments();
    }
  }
}
