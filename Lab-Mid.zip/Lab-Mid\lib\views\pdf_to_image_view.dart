import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/document_model.dart';
import '../providers/document_provider.dart';
import '../services/pdf_service.dart';
import '../services/export_service.dart';

class PdfToImageView extends StatefulWidget {
  final DocumentModel? selectedDocument;
  final int? initialPage;

  const PdfToImageView({
    Key? key,
    this.selectedDocument,
    this.initialPage,
  }) : super(key: key);

  @override
  State<PdfToImageView> createState() => _PdfToImageViewState();
}

class _PdfToImageViewState extends State<PdfToImageView> {
  DocumentModel? _document;
  bool _convertAllPages = true;
  int _selectedPage = 1;
  bool _asPng = false; // true = PNG, false = JPG
  bool _isConverting = false;
  List<File> _convertedImages = [];

  @override
  void initState() {
    super.initState();
    _document = widget.selectedDocument;
    if (widget.initialPage != null) {
      _selectedPage = widget.initialPage!;
      _convertAllPages = false;
    }
  }

  Future<void> _runConversion() async {
    if (_document == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select a PDF document first')),
      );
      return;
    }

    setState(() {
      _isConverting = true;
      _convertedImages = [];
    });

    try {
      final List<int>? pagesToConvert = _convertAllPages ? null : [_selectedPage];
      final images = await PdfService.convertPdfToImages(
        document: _document!,
        pageNumbers: pagesToConvert,
        asPng: _asPng,
      );

      setState(() {
        _convertedImages = images;
      });

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Successfully converted ${images.length} page(s) to ${_asPng ? 'PNG' : 'JPG'}!')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Conversion failed: $e'), backgroundColor: Colors.red),
      );
    } finally {
      if (mounted) setState(() => _isConverting = false);
    }
  }

  void _shareAllImages() async {
    if (_convertedImages.isEmpty) return;
    for (var img in _convertedImages) {
      await ExportService.shareFile(
        img,
        text: 'Converted page from ${_document?.title ?? 'PDF'}',
        subject: 'PDF Converted Page',
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final docProvider = context.watch<DocumentProvider>();
    final allDocs = docProvider.documents;
    final theme = Theme.of(context);

    // If no document selected yet and documents exist, pick the first
    if (_document == null && allDocs.isNotEmpty) {
      _document = allDocs.first;
    }

    final totalPages = _document != null && _document!.pageCount > 0 ? _document!.pageCount : 1;

    return Scaffold(
      appBar: AppBar(
        title: const Text('PDF to Image Converter'),
        actions: [
          if (_convertedImages.isNotEmpty)
            IconButton(
              icon: const Icon(Icons.share_rounded),
              tooltip: 'Share Converted Images',
              onPressed: _shareAllImages,
            ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Select Document Card
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Select Document', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 10),
                    if (allDocs.isEmpty)
                      const Text('No documents available in library to convert.')
                    else
                      DropdownButtonFormField<DocumentModel>(
                        value: _document,
                        isExpanded: true,
                        decoration: const InputDecoration(
                          prefixIcon: Icon(Icons.picture_as_pdf, color: Colors.red),
                        ),
                        items: allDocs.map((doc) {
                          return DropdownMenuItem<DocumentModel>(
                            value: doc,
                            child: Text(
                              doc.title,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          );
                        }).toList(),
                        onChanged: (val) {
                          setState(() {
                            _document = val;
                            _selectedPage = 1;
                            _convertedImages = [];
                          });
                        },
                      ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Conversion Settings Card
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Conversion Scope', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 10),

                    RadioListTile<bool>(
                      title: const Text('Convert All Pages'),
                      subtitle: Text('Export every page (1 to $totalPages) as an individual image'),
                      value: true,
                      groupValue: _convertAllPages,
                      onChanged: (val) => setState(() => _convertAllPages = val ?? true),
                    ),
                    RadioListTile<bool>(
                      title: const Text('Convert Single Page'),
                      subtitle: Text('Export page $_selectedPage of $totalPages'),
                      value: false,
                      groupValue: _convertAllPages,
                      onChanged: (val) => setState(() => _convertAllPages = val ?? false),
                    ),

                    if (!_convertAllPages) ...[
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        child: Row(
                          children: [
                            const Text('Page: ', style: TextStyle(fontWeight: FontWeight.bold)),
                            Expanded(
                              child: Slider(
                                value: _selectedPage.toDouble().clamp(1.0, totalPages.toDouble()),
                                min: 1.0,
                                max: totalPages.toDouble(),
                                divisions: totalPages > 1 ? totalPages - 1 : 1,
                                label: 'Page $_selectedPage',
                                onChanged: (val) => setState(() => _selectedPage = val.toInt()),
                              ),
                            ),
                            Text('$_selectedPage / $totalPages', style: const TextStyle(fontWeight: FontWeight.bold)),
                          ],
                        ),
                      ),
                    ],

                    const Divider(height: 24),

                    // Output Format Selector
                    Text('Output Image Format', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        ChoiceChip(
                          label: const Text('JPG Format (High Quality)'),
                          selected: !_asPng,
                          onSelected: (_) => setState(() => _asPng = false),
                        ),
                        const SizedBox(width: 10),
                        ChoiceChip(
                          label: const Text('PNG Format (Lossless)'),
                          selected: _asPng,
                          onSelected: (_) => setState(() => _asPng = true),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),

                    // Action Button
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        onPressed: _isConverting ? null : _runConversion,
                        icon: _isConverting
                            ? const SizedBox(
                                width: 18,
                                height: 18,
                                child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                              )
                            : const Icon(Icons.transform_rounded),
                        label: Text(_isConverting ? 'Converting...' : 'Convert to Images'),
                        style: ElevatedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 14),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),

            // Results Section
            if (_convertedImages.isNotEmpty) ...[
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Converted Images (${_convertedImages.length})',
                    style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
                  ),
                  TextButton.icon(
                    onPressed: _shareAllImages,
                    icon: const Icon(Icons.share, size: 16),
                    label: const Text('Share All'),
                  ),
                ],
              ),
              const SizedBox(height: 10),

              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  childAspectRatio: 0.75,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                ),
                itemCount: _convertedImages.length,
                itemBuilder: (ctx, idx) {
                  final imgFile = _convertedImages[idx];
                  return Card(
                    clipBehavior: Clip.antiAlias,
                    child: Column(
                      children: [
                        Expanded(
                          child: Image.file(
                            imgFile,
                            fit: BoxFit.cover,
                            width: double.infinity,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Page ${idx + 1}',
                                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 11),
                              ),
                              IconButton(
                                icon: const Icon(Icons.share, size: 16),
                                onPressed: () => ExportService.shareFile(
                                  imgFile,
                                  subject: 'Converted Page ${idx + 1}',
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ],
          ],
        ),
      ),
    );
  }
}
