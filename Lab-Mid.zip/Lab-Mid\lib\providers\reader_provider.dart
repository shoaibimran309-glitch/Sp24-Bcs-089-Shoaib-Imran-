import 'package:flutter/foundation.dart';
import '../models/document_model.dart';
import '../models/bookmark_model.dart';
import '../models/reading_history_model.dart';
import '../database/db_helper.dart';

class ReaderProvider extends ChangeNotifier {
  DocumentModel? _currentDocument;
  int _currentPage = 1;
  int _totalPages = 1;
  double _readingProgress = 0.0;
  List<BookmarkModel> _documentBookmarks = [];
  List<BookmarkModel> _allBookmarks = [];
  List<ReadingHistoryModel> _readingHistory = [];
  bool _isLoadingHistory = false;

  DocumentModel? get currentDocument => _currentDocument;
  int get currentPage => _currentPage;
  int get totalPages => _totalPages;
  double get readingProgress => _readingProgress;
  List<BookmarkModel> get documentBookmarks => _documentBookmarks;
  List<BookmarkModel> get allBookmarks => _allBookmarks;
  List<ReadingHistoryModel> get readingHistory => _readingHistory;
  bool get isLoadingHistory => _isLoadingHistory;

  /// Open a document and load its reading state and bookmarks
  Future<void> openDocument(DocumentModel doc) async {
    _currentDocument = doc;
    _currentPage = doc.lastReadPage.clamp(1, doc.pageCount > 0 ? doc.pageCount : 1);
    _totalPages = doc.pageCount > 0 ? doc.pageCount : 1;
    _readingProgress = doc.readingProgress;

    if (doc.id != null) {
      await DatabaseHelper.instance.updateLastOpened(doc.id!);
      await loadDocumentBookmarks(doc.id!);
    }

    notifyListeners();
  }

  /// Update reading state when user turns page
  Future<void> onPageChanged(int page, int total) async {
    _currentPage = page;
    _totalPages = total > 0 ? total : 1;
    _readingProgress = (_currentPage / _totalPages).clamp(0.0, 1.0);

    if (_currentDocument != null && _currentDocument!.id != null) {
      // Update SQLite document progress
      await DatabaseHelper.instance.updateReadingProgress(
        _currentDocument!.id!,
        _currentPage,
        _readingProgress,
      );

      // Record reading history
      final history = ReadingHistoryModel(
        documentId: _currentDocument!.id!,
        documentTitle: _currentDocument!.title,
        pageNumber: _currentPage,
        totalPages: _totalPages,
        progressPercentage: _readingProgress,
        timestamp: DateTime.now(),
      );
      await DatabaseHelper.instance.addReadingHistory(history);
    }

    notifyListeners();
  }

  /// Load bookmarks for the active document
  Future<void> loadDocumentBookmarks(int docId) async {
    _documentBookmarks = await DatabaseHelper.instance.getBookmarksForDocument(docId);
    notifyListeners();
  }

  /// Load all bookmarks across all documents (for Favorites / Bookmarks view)
  Future<void> loadAllBookmarks() async {
    _allBookmarks = await DatabaseHelper.instance.getAllBookmarks();
    notifyListeners();
  }

  /// Check if the current page in the reader is bookmarked
  bool isPageBookmarked(int page) {
    return _documentBookmarks.any((bm) => bm.pageNumber == page);
  }

  /// Toggle bookmark on current page
  Future<void> toggleBookmarkCurrentPage({String note = ''}) async {
    if (_currentDocument == null || _currentDocument!.id == null) return;

    final docId = _currentDocument!.id!;
    final isAlreadyBookmarked = isPageBookmarked(_currentPage);

    if (isAlreadyBookmarked) {
      await DatabaseHelper.instance.deleteBookmarkByPage(docId, _currentPage);
    } else {
      final bookmark = BookmarkModel(
        documentId: docId,
        documentTitle: _currentDocument!.title,
        pageNumber: _currentPage,
        note: note.isEmpty ? 'Page $_currentPage Bookmark' : note,
        createdAt: DateTime.now(),
      );
      await DatabaseHelper.instance.insertBookmark(bookmark);
    }

    await loadDocumentBookmarks(docId);
    await loadAllBookmarks();
  }

  /// Delete a bookmark by ID
  Future<void> deleteBookmark(int id) async {
    await DatabaseHelper.instance.deleteBookmark(id);
    if (_currentDocument != null && _currentDocument!.id != null) {
      await loadDocumentBookmarks(_currentDocument!.id!);
    }
    await loadAllBookmarks();
  }

  /// Load all reading history
  Future<void> loadReadingHistory() async {
    _isLoadingHistory = true;
    notifyListeners();
    try {
      _readingHistory = await DatabaseHelper.instance.getReadingHistory();
    } finally {
      _isLoadingHistory = false;
      notifyListeners();
    }
  }

  /// Clear all reading history
  Future<void> clearHistory() async {
    await DatabaseHelper.instance.clearHistory();
    _readingHistory = [];
    notifyListeners();
  }
}
