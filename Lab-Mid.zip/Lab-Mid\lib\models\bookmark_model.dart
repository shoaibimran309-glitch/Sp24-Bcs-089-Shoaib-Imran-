/// Model representing a page bookmark within a PDF document.
/// Maps directly to the 'bookmarks' table in SQLite.
class BookmarkModel {
  final int? id;
  final int documentId;
  final String documentTitle;
  final int pageNumber;
  final String note;
  final DateTime createdAt;

  BookmarkModel({
    this.id,
    required this.documentId,
    this.documentTitle = '',
    required this.pageNumber,
    this.note = '',
    required this.createdAt,
  });

  BookmarkModel copyWith({
    int? id,
    int? documentId,
    String? documentTitle,
    int? pageNumber,
    String? note,
    DateTime? createdAt,
  }) {
    return BookmarkModel(
      id: id ?? this.id,
      documentId: documentId ?? this.documentId,
      documentTitle: documentTitle ?? this.documentTitle,
      pageNumber: pageNumber ?? this.pageNumber,
      note: note ?? this.note,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'document_id': documentId,
      'document_title': documentTitle,
      'page_number': pageNumber,
      'note': note,
      'created_at': createdAt.toIso8601String(),
    };
  }

  factory BookmarkModel.fromMap(Map<String, dynamic> map) {
    return BookmarkModel(
      id: map['id'] as int?,
      documentId: (map['document_id'] as num?)?.toInt() ?? 0,
      documentTitle: map['document_title'] as String? ?? '',
      pageNumber: (map['page_number'] as num?)?.toInt() ?? 1,
      note: map['note'] as String? ?? '',
      createdAt: map['created_at'] != null 
          ? DateTime.tryParse(map['created_at'] as String) ?? DateTime.now() 
          : DateTime.now(),
    );
  }
}
