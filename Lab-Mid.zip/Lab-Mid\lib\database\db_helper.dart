import 'dart:async';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import '../models/document_model.dart';
import '../models/bookmark_model.dart';
import '../models/reading_history_model.dart';
import '../utils/constants.dart';

/// Database helper implementing SQLite persistence for the PDF Reader application.
/// Manages documents, bookmarks, reading history, and user settings.
class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._init();
  static Database? _database;

  DatabaseHelper._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB(AppConstants.dbName);
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);

    return await openDatabase(
      path,
      version: AppConstants.dbVersion,
      onCreate: _createDB,
      onConfigure: _onConfigure,
    );
  }

  /// Enable Foreign Key constraints in SQLite
  Future<void> _onConfigure(Database db) async {
    await db.execute('PRAGMA foreign_keys = ON');
  }

  /// Creates all required database tables matching functional specifications
  Future<void> _createDB(Database db, int version) async {
    // 1. Documents Table
    await db.execute('''
      CREATE TABLE ${AppConstants.tableDocuments} (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        file_path TEXT NOT NULL,
        file_size INTEGER NOT NULL DEFAULT 0,
        page_count INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL,
        last_opened TEXT NOT NULL,
        is_favorite INTEGER NOT NULL DEFAULT 0,
        tags TEXT DEFAULT '',
        description TEXT DEFAULT '',
        last_read_page INTEGER NOT NULL DEFAULT 1,
        reading_progress REAL NOT NULL DEFAULT 0.0
      )
    ''');

    // 2. Bookmarks Table with Foreign Key cascade
    await db.execute('''
      CREATE TABLE ${AppConstants.tableBookmarks} (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        document_id INTEGER NOT NULL,
        document_title TEXT DEFAULT '',
        page_number INTEGER NOT NULL,
        note TEXT DEFAULT '',
        created_at TEXT NOT NULL,
        FOREIGN KEY (document_id) REFERENCES ${AppConstants.tableDocuments} (id) ON DELETE CASCADE
      )
    ''');

    // 3. Reading History Table
    await db.execute('''
      CREATE TABLE ${AppConstants.tableReadingHistory} (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        document_id INTEGER NOT NULL,
        document_title TEXT NOT NULL,
        page_number INTEGER NOT NULL,
        total_pages INTEGER NOT NULL,
        progress_percentage REAL NOT NULL,
        timestamp TEXT NOT NULL,
        FOREIGN KEY (document_id) REFERENCES ${AppConstants.tableDocuments} (id) ON DELETE CASCADE
      )
    ''');

    // 4. User Preferences Table
    await db.execute('''
      CREATE TABLE ${AppConstants.tablePreferences} (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
      )
    ''');
  }

  // ==========================================
  // DOCUMENT CRUD OPERATIONS
  // ==========================================

  Future<int> insertDocument(DocumentModel doc) async {
    final db = await database;
    return await db.insert(
      AppConstants.tableDocuments,
      doc.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<DocumentModel>> getAllDocuments({
    String? searchQuery,
    String? tag,
    bool? favoritesOnly,
    String sortBy = 'last_opened_desc',
  }) async {
    final db = await database;

    List<String> whereClauses = [];
    List<dynamic> whereArgs = [];

    if (searchQuery != null && searchQuery.trim().isNotEmpty) {
      final query = '%${searchQuery.trim()}%';
      whereClauses.add('(title LIKE ? OR description LIKE ? OR tags LIKE ?)');
      whereArgs.addAll([query, query, query]);
    }

    if (tag != null && tag.isNotEmpty && tag != 'All') {
      whereClauses.add('tags LIKE ?');
      whereArgs.add('%$tag%');
    }

    if (favoritesOnly == true) {
      whereClauses.add('is_favorite = 1');
    }

    String? where = whereClauses.isNotEmpty ? whereClauses.join(' AND ') : null;

    String orderBy;
    switch (sortBy) {
      case 'title_asc':
        orderBy = 'title COLLATE NOCASE ASC';
        break;
      case 'title_desc':
        orderBy = 'title COLLATE NOCASE DESC';
        break;
      case 'date_desc':
        orderBy = 'created_at DESC';
        break;
      case 'size_desc':
        orderBy = 'file_size DESC';
        break;
      case 'progress_desc':
        orderBy = 'reading_progress DESC';
        break;
      case 'last_opened_desc':
      default:
        orderBy = 'last_opened DESC';
        break;
    }

    final maps = await db.query(
      AppConstants.tableDocuments,
      where: where,
      whereArgs: whereArgs.isNotEmpty ? whereArgs : null,
      orderBy: orderBy,
    );

    return maps.map((map) => DocumentModel.fromMap(map)).toList();
  }

  Future<DocumentModel?> getDocumentById(int id) async {
    final db = await database;
    final maps = await db.query(
      AppConstants.tableDocuments,
      where: 'id = ?',
      whereArgs: [id],
      limit: 1,
    );
    if (maps.isNotEmpty) {
      return DocumentModel.fromMap(maps.first);
    }
    return null;
  }

  Future<int> updateDocument(DocumentModel doc) async {
    final db = await database;
    return await db.update(
      AppConstants.tableDocuments,
      doc.toMap(),
      where: 'id = ?',
      whereArgs: [doc.id],
    );
  }

  Future<int> updateDocumentMetadata(int id, String title, String tags, String description) async {
    final db = await database;
    return await db.update(
      AppConstants.tableDocuments,
      {
        'title': title,
        'tags': tags,
        'description': description,
      },
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<int> updateReadingProgress(int id, int lastReadPage, double progress) async {
    final db = await database;
    return await db.update(
      AppConstants.tableDocuments,
      {
        'last_read_page': lastReadPage,
        'reading_progress': progress,
        'last_opened': DateTime.now().toIso8601String(),
      },
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<int> toggleFavorite(int id, bool isFavorite) async {
    final db = await database;
    return await db.update(
      AppConstants.tableDocuments,
      {'is_favorite': isFavorite ? 1 : 0},
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<int> updateLastOpened(int id) async {
    final db = await database;
    return await db.update(
      AppConstants.tableDocuments,
      {'last_opened': DateTime.now().toIso8601String()},
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<int> deleteDocument(int id) async {
    final db = await database;
    // Foreign key cascade takes care of bookmarks and history
    return await db.delete(
      AppConstants.tableDocuments,
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  // ==========================================
  // BOOKMARK CRUD OPERATIONS
  // ==========================================

  Future<int> insertBookmark(BookmarkModel bookmark) async {
    final db = await database;
    return await db.insert(
      AppConstants.tableBookmarks,
      bookmark.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<BookmarkModel>> getBookmarksForDocument(int docId) async {
    final db = await database;
    final maps = await db.query(
      AppConstants.tableBookmarks,
      where: 'document_id = ?',
      whereArgs: [docId],
      orderBy: 'page_number ASC',
    );
    return maps.map((map) => BookmarkModel.fromMap(map)).toList();
  }

  Future<List<BookmarkModel>> getAllBookmarks() async {
    final db = await database;
    final maps = await db.query(
      AppConstants.tableBookmarks,
      orderBy: 'created_at DESC',
    );
    return maps.map((map) => BookmarkModel.fromMap(map)).toList();
  }

  Future<bool> isPageBookmarked(int docId, int pageNumber) async {
    final db = await database;
    final result = await db.query(
      AppConstants.tableBookmarks,
      where: 'document_id = ? AND page_number = ?',
      whereArgs: [docId, pageNumber],
      limit: 1,
    );
    return result.isNotEmpty;
  }

  Future<int> deleteBookmark(int id) async {
    final db = await database;
    return await db.delete(
      AppConstants.tableBookmarks,
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<int> deleteBookmarkByPage(int docId, int pageNumber) async {
    final db = await database;
    return await db.delete(
      AppConstants.tableBookmarks,
      where: 'document_id = ? AND page_number = ?',
      whereArgs: [docId, pageNumber],
    );
  }

  // ==========================================
  // READING HISTORY OPERATIONS
  // ==========================================

  Future<int> addReadingHistory(ReadingHistoryModel history) async {
    final db = await database;
    return await db.insert(
      AppConstants.tableReadingHistory,
      history.toMap(),
    );
  }

  Future<List<ReadingHistoryModel>> getReadingHistory({int limit = 50}) async {
    final db = await database;
    final maps = await db.query(
      AppConstants.tableReadingHistory,
      orderBy: 'timestamp DESC',
      limit: limit,
    );
    return maps.map((map) => ReadingHistoryModel.fromMap(map)).toList();
  }

  Future<int> clearHistory() async {
    final db = await database;
    return await db.delete(AppConstants.tableReadingHistory);
  }

  // ==========================================
  // USER PREFERENCES OPERATIONS
  // ==========================================

  Future<void> savePreference(String key, String value) async {
    final db = await database;
    await db.insert(
      AppConstants.tablePreferences,
      {'key': key, 'value': value},
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<String?> getPreference(String key) async {
    final db = await database;
    final result = await db.query(
      AppConstants.tablePreferences,
      where: 'key = ?',
      whereArgs: [key],
      limit: 1,
    );
    if (result.isNotEmpty) {
      return result.first['value'] as String?;
    }
    return null;
  }

  Future<Map<String, String>> getAllPreferences() async {
    final db = await database;
    final result = await db.query(AppConstants.tablePreferences);
    final Map<String, String> map = {};
    for (var row in result) {
      map[row['key'] as String] = row['value'] as String;
    }
    return map;
  }

  /// Close database
  Future<void> close() async {
    final db = await database;
    db.close();
    _database = null;
  }
}
