import 'package:flutter/material.dart';

class ReadingProgressBar extends StatelessWidget {
  final double progress; // 0.0 to 1.0
  final double height;
  final bool showText;
  final Color? progressColor;
  final Color? backgroundColor;

  const ReadingProgressBar({
    Key? key,
    required this.progress,
    this.height = 6,
    this.showText = false,
    this.progressColor,
    this.backgroundColor,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final clampedProgress = progress.clamp(0.0, 1.0);
    final theme = Theme.of(context);
    final activeColor = progressColor ??
        (clampedProgress >= 0.99
            ? Colors.green
            : theme.colorScheme.primary);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(height / 2),
          child: LinearProgressIndicator(
            value: clampedProgress,
            minHeight: height,
            backgroundColor: backgroundColor ?? theme.colorScheme.surfaceContainerHighest.withOpacity(0.4),
            valueColor: AlwaysStoppedAnimation<Color>(activeColor),
          ),
        ),
        if (showText) ...[
          const SizedBox(height: 4),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                clampedProgress >= 0.99 ? 'Completed' : 'Reading Progress',
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w500,
                  color: clampedProgress >= 0.99 ? Colors.green : Colors.grey.shade600,
                ),
              ),
              Text(
                '${(clampedProgress * 100).toInt()}%',
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                  color: activeColor,
                ),
              ),
            ],
          ),
        ],
      ],
    );
  }
}
