import 'dart:io';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class NotificationService {
  static final NotificationService instance = NotificationService._internal();
  factory NotificationService() => instance;
  NotificationService._internal();

  final FlutterLocalNotificationsPlugin _notificationsPlugin = FlutterLocalNotificationsPlugin();
  bool _isInitialized = false;

  Future<void> init() async {
    if (_isInitialized) return;

    const AndroidInitializationSettings androidSettings =
        AndroidInitializationSettings('@mipmap/ic_launcher');

    const DarwinInitializationSettings iosSettings = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );

    const InitializationSettings initSettings = InitializationSettings(
      android: androidSettings,
      iOS: iosSettings,
    );

    await _notificationsPlugin.initialize(
      initSettings,
      onDidReceiveNotificationResponse: (NotificationResponse response) {
        // Handle notification click
      },
    );

    _isInitialized = true;
    await requestPermissions();
  }

  /// Request permissions on Android 13+ and iOS
  Future<bool?> requestPermissions() async {
    if (Platform.isAndroid) {
      final androidImplementation = _notificationsPlugin
          .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
      return await androidImplementation?.requestNotificationsPermission();
    }
    return true;
  }

  /// Show an instant local notification
  Future<void> showNotification({
    int id = 100,
    required String title,
    required String body,
    String? sound,
  }) async {
    final AndroidNotificationDetails androidDetails = AndroidNotificationDetails(
      'pdf_reader_main_channel',
      'PDF Reader Notifications',
      channelDescription: 'Notifications for reading goals, reminders and imports',
      importance: Importance.max,
      priority: Priority.high,
      ticker: 'PDF Reader',
      styleInformation: BigTextStyleInformation(body),
    );

    final NotificationDetails notificationDetails = NotificationDetails(
      android: androidDetails,
      iOS: const DarwinNotificationDetails(),
    );

    await _notificationsPlugin.show(
      id,
      title,
      body,
      notificationDetails,
    );
  }

  /// Trigger notification when a new PDF document is added or scanned
  Future<void> showDocumentAddedNotification(String documentTitle) async {
    await showNotification(
      id: 201,
      title: 'New Document Added 📄',
      body: '"$documentTitle" has been saved to your library and indexed.',
    );
  }

  /// Trigger reading goal alert
  Future<void> showReadingGoalReminder(int goalMinutes) async {
    await showNotification(
      id: 202,
      title: 'Daily Reading Goal Reminder ⏰',
      body: 'Keep up your reading habit! Spend $goalMinutes minutes reading your documents today.',
    );
  }

  /// Trigger scheduled reading session alert
  Future<void> scheduleReadingSession({
    required int hour,
    required int minute,
    required int goalMinutes,
  }) async {
    // Show confirmation notification
    final timeStr = '${hour.toString().padLeft(2, '0')}:${minute.toString().padLeft(2, '0')}';
    await showNotification(
      id: 203,
      title: 'Reading Reminder Scheduled 🎯',
      body: 'Daily reminder is active for $timeStr. Goal: $goalMinutes mins per day.',
    );
  }

  /// Cancel all scheduled and active notifications
  Future<void> cancelAll() async {
    await _notificationsPlugin.cancelAll();
  }
}
