import 'dart:io';
import 'package:csv/csv.dart';
import 'package:intl/intl.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';
import '../database/db_helper.dart';

class ExportService {
  /// Export all document metadata, reading history, and bookmarks into a formatted CSV file
  static Future<File> exportDataToCsv() async {
    final docs = await DatabaseHelper.instance.getAllDocuments();
    final bookmarks = await DatabaseHelper.instance.getAllBookmarks();
    final history = await DatabaseHelper.instance.getReadingHistory();

    List<List<dynamic>> csvRows = [];

    // SECTION 1: DOCUMENTS METADATA
    csvRows.add(['=== PDF READER & UTILITY - DOCUMENT METADATA ===']);
    csvRows.add([
      'Document ID',
      'Title',
      'File Size',
      'Total Pages',
      'Tags',
      'Description',
      'Is Favorite',
      'Last Read Page',
      'Reading Progress %',
      'Created Date',
      'Last Opened Date',
      'File Path'
    ]);

    for (var doc in docs) {
      csvRows.add([
        doc.id,
        doc.title,
        doc.formattedFileSize,
        doc.pageCount,
        doc.tags,
        doc.description,
        doc.isFavorite ? 'Yes' : 'No',
        doc.lastReadPage,
        '${(doc.readingProgress * 100).toInt()}%',
        DateFormat('yyyy-MM-dd HH:mm').format(doc.createdAt),
        DateFormat('yyyy-MM-dd HH:mm').format(doc.lastOpened),
        doc.filePath,
      ]);
    }

    csvRows.add([]);
    csvRows.add([]);

    // SECTION 2: BOOKMARKS
    csvRows.add(['=== BOOKMARKS LOG ===']);
    csvRows.add(['Bookmark ID', 'Document ID', 'Document Title', 'Page Number', 'Note', 'Date Created']);
    for (var bm in bookmarks) {
      csvRows.add([
        bm.id,
        bm.documentId,
        bm.documentTitle,
        bm.pageNumber,
        bm.note,
        DateFormat('yyyy-MM-dd HH:mm').format(bm.createdAt),
      ]);
    }

    csvRows.add([]);
    csvRows.add([]);

    // SECTION 3: READING HISTORY
    csvRows.add(['=== READING SESSIONS HISTORY ===']);
    csvRows.add(['Log ID', 'Document Title', 'Page Reached', 'Total Pages', 'Progress %', 'Timestamp']);
    for (var h in history) {
      csvRows.add([
        h.id,
        h.documentTitle,
        h.pageNumber,
        h.totalPages,
        '${(h.progressPercentage * 100).toInt()}%',
        DateFormat('yyyy-MM-dd HH:mm').format(h.timestamp),
      ]);
    }

    final csvString = const ListToCsvConverter().convert(csvRows);
    final tempDir = await getTemporaryDirectory();
    final fileName = 'PDF_Reader_Export_${DateFormat('yyyyMMdd_HHmmss').format(DateTime.now())}.csv';
    final file = File(p.join(tempDir.path, fileName));

    await file.writeAsString(csvString);
    return file;
  }

  /// Generate a beautiful analytical summary report in PDF format
  static Future<File> generateSummaryPdfReport() async {
    final docs = await DatabaseHelper.instance.getAllDocuments();
    final bookmarks = await DatabaseHelper.instance.getAllBookmarks();
    final history = await DatabaseHelper.instance.getReadingHistory(limit: 20);

    final pdf = pw.Document();

    final dateFormat = DateFormat('yyyy-MM-dd HH:mm');
    final completedCount = docs.where((d) => d.readingProgress >= 0.99).length;
    final inProgressCount = docs.where((d) => d.readingProgress > 0 && d.readingProgress < 0.99).length;

    pdf.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(32),
        build: (pw.Context context) {
          return [
            // Header Banner
            pw.Container(
              padding: const pw.EdgeInsets.all(16),
              decoration: pw.BoxDecoration(
                color: PdfColor.fromHex('#1E3A8A'),
                borderRadius: pw.BorderRadius.circular(8),
              ),
              child: pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Text(
                    'Comprehensive PDF Reader & Utility',
                    style: pw.TextStyle(
                      color: PdfColors.white,
                      fontSize: 18,
                      fontWeight: pw.FontWeight.bold,
                    ),
                  ),
                  pw.SizedBox(height: 4),
                  pw.Text(
                    'User Reading Progress & Metadata Report',
                    style: const pw.TextStyle(
                      color: PdfColors.white,
                      fontSize: 12,
                    ),
                  ),
                  pw.SizedBox(height: 6),
                  pw.Text(
                    'Generated on: ${dateFormat.format(DateTime.now())}',
                    style: const pw.TextStyle(
                      color: PdfColors.grey200,
                      fontSize: 9,
                    ),
                  ),
                ],
              ),
            ),
            pw.SizedBox(height: 20),

            // Metrics Summary Row
            pw.Row(
              mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
              children: [
                _buildStatBox('Total Documents', '${docs.length}', PdfColor.fromHex('#2563EB')),
                _buildStatBox('Completed', '$completedCount', PdfColor.fromHex('#16A34A')),
                _buildStatBox('In Progress', '$inProgressCount', PdfColor.fromHex('#EA580C')),
                _buildStatBox('Total Bookmarks', '${bookmarks.length}', PdfColor.fromHex('#9333EA')),
              ],
            ),
            pw.SizedBox(height: 24),

            // Document Catalog Table
            pw.Text(
              'Document Library Overview',
              style: pw.TextStyle(fontSize: 14, fontWeight: pw.FontWeight.bold, color: PdfColor.fromHex('#1E3A8A')),
            ),
            pw.SizedBox(height: 8),
            pw.TableHelper.fromTextArray(
              headers: ['Title', 'Pages', 'Size', 'Progress', 'Favorite', 'Tags'],
              data: docs.map((d) => [
                d.title.length > 25 ? '${d.title.substring(0, 22)}...' : d.title,
                '${d.lastReadPage} / ${d.pageCount}',
                d.formattedFileSize,
                d.progressPercentageString,
                d.isFavorite ? 'Yes' : 'No',
                d.tags.isEmpty ? '-' : d.tags,
              ]).toList(),
              headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold, color: PdfColors.white, fontSize: 9),
              headerDecoration: pw.BoxDecoration(color: PdfColor.fromHex('#1E3A8A')),
              cellStyle: const pw.TextStyle(fontSize: 8),
              cellAlignment: pw.Alignment.centerLeft,
              cellPadding: const pw.EdgeInsets.symmetric(horizontal: 6, vertical: 5),
            ),
            pw.SizedBox(height: 24),

            // Recent Reading History Table
            if (history.isNotEmpty) ...[
              pw.Text(
                'Recent Reading History Log',
                style: pw.TextStyle(fontSize: 14, fontWeight: pw.FontWeight.bold, color: PdfColor.fromHex('#1E3A8A')),
              ),
              pw.SizedBox(height: 8),
              pw.TableHelper.fromTextArray(
                headers: ['Document', 'Page', 'Progress', 'Timestamp'],
                data: history.map((h) => [
                  h.documentTitle.length > 30 ? '${h.documentTitle.substring(0, 27)}...' : h.documentTitle,
                  'Page ${h.pageNumber} / ${h.totalPages}',
                  '${(h.progressPercentage * 100).toInt()}%',
                  dateFormat.format(h.timestamp),
                ]).toList(),
                headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold, color: PdfColors.white, fontSize: 9),
                headerDecoration: pw.BoxDecoration(color: PdfColor.fromHex('#334155')),
                cellStyle: const pw.TextStyle(fontSize: 8),
                cellAlignment: pw.Alignment.centerLeft,
                cellPadding: const pw.EdgeInsets.symmetric(horizontal: 6, vertical: 5),
              ),
            ],
          ];
        },
      ),
    );

    final tempDir = await getTemporaryDirectory();
    final fileName = 'PDF_Reader_Report_${DateFormat('yyyyMMdd_HHmmss').format(DateTime.now())}.pdf';
    final file = File(p.join(tempDir.path, fileName));

    await file.writeAsBytes(await pdf.save());
    return file;
  }

  static pw.Widget _buildStatBox(String label, String value, PdfColor color) {
    return pw.Container(
      width: 110,
      padding: const pw.EdgeInsets.symmetric(vertical: 10, horizontal: 8),
      decoration: pw.BoxDecoration(
        border: pw.Border.all(color: color, width: 1.5),
        borderRadius: pw.BorderRadius.circular(6),
      ),
      child: pw.Column(
        children: [
          pw.Text(
            value,
            style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold, color: color),
          ),
          pw.SizedBox(height: 4),
          pw.Text(
            label,
            style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey700),
            textAlign: pw.TextAlign.center,
          ),
        ],
      ),
    );
  }

  /// Share file via system share sheet (WhatsApp, Drive, Email, etc.)
  static Future<void> shareFile(File file, {String? text, String? subject}) async {
    final xFile = XFile(file.path);
    await Share.shareXFiles(
      [xFile],
      text: text ?? 'Exported file from PDF Reader & Utility App',
      subject: subject ?? 'PDF Reader Data Export',
    );
  }

  /// Share via Email specifically
  static Future<void> shareViaEmail(File file, {String? subject, String? body}) async {
    final xFile = XFile(file.path);
    await Share.shareXFiles(
      [xFile],
      text: body ?? 'Please find attached the exported data from the PDF Reader application.',
      subject: subject ?? 'PDF Reader & Utility Export',
    );
  }
}
